from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['astro@gmail.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    'workFlow_Echo',
    default_args=default_args,
    description='A simple DAG',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2023, 1, 1),
    catchup=False,
    tags=['work'],
) as dag:

    start_task = BashOperator(
        task_id='start',
        bash_command='echo "Starting the workflow"',
    )

    processing_task = BashOperator(
        task_id='processing',
        bash_command='echo "Processing data"',
    )

    end_task = BashOperator(
        task_id='end',
        bash_command='echo "Workflow finished"',
    )

    start_task >> processing_task >> end_task
