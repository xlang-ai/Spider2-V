# External Links Information:

1. name = "WTTRWeather", link = "https://wttr.in/HongKong"

2. name = "HTTP file", link = "https://developer.mozilla.org/en-US/docs/Web/HTTP"
