## Help me implement the following assets

- linear_regression_model: Define a linear regression model fit on the transformed_training_data.
- comments_model_test_score: Compute the R-squared score on the transformed_test_data.
- latest_story_comment_predictions: Run predictions using the latest_story_data as input.