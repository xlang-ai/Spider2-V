import pandas as pd
from dagstermill import define_dagstermill_asset

from dagster import AssetIn, Field, Int, asset, file_relative_path

@asset(group_name="classification")
def iris_data():
    return pd.read_csv(
        "https://docs.dagster.io/assets/iris.csv",
        names=[
            "Sepal length (cm)",
            "Sepal width (cm)",
            "Petal length (cm)",
            "Petal width (cm)",
            "Species",
        ],
    )
