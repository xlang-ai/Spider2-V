
import json
import os

import requests
from dagster import asset, AssetExecutionContext

@asset # add the asset decorator to tell Dagster this is an asset
def top10_story_ids() -> None:
    newstories_url = "https://hacker-news.firebaseio.com/v0/topstories.json"
    top_new_story_ids = requests.get(newstories_url).json()[:10]

    os.makedirs("data", exist_ok=True)
    with open("data/story_ids.json", "w") as f:
        json.dump(top_new_story_ids, f, ensure_ascii=False, indent=4)


@asset(deps=[top10_story_ids])
def top10_stories(context: AssetExecutionContext) -> None:
    with open("data/story_ids.json", "r") as f:
        topstory_ids = json.load(f)

    results = []
    for item_id in topstory_ids:
        item = requests.get(
            f"https://hacker-news.firebaseio.com/v0/item/{item_id}.json"
        ).json()
        results.append(item)

        if len(results) % 20 == 0:
            context.log.info(f"Got {len(results)} items so far.")

    with open('data/stories.json', 'w') as of:
        json.dump(results, of, indent=4, ensure_ascii=False)


@asset(deps=[top10_stories])
def top5_mfw() -> None:
    stopwords = []
    with open('stopwords.txt', 'r') as inf:
        for line in inf:
            word = line.strip()
            if word == '': continue
            stopwords.append(word)

    with open('data/stories.json', 'r') as inf:
        topstories = json.load(inf)

    # loop through the titles and count the frequency of each word
    word_counts = {}
    for story in topstories:
        title = story["title"]
        for word in title.lower().split():
            if word not in stopwords and len(word) > 0:
                word_counts[word] = word_counts.get(word, 0) + 1

    # Get the top 5 most frequent words
    top_words = {
        pair[0]: pair[1]
        for pair in sorted(word_counts.items(), key=lambda x: x[1], reverse=True)[:5]
    }

    with open("data/mfw.json", "w") as f:
        json.dump(top_words, f, ensure_ascii=False, indent=4)