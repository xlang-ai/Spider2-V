## Tasks
- Our goal is to migrate an Airflow project `dags/wikipediaPageViews.py` into Dagster.
- Please finish the code in `dagster_migration.py` to configure the database connection and project migration.
- Enable the hourly schedule in Dagster UI and ensure all jobs are successful.

## Connection to MySQL database
- conn_id: mysql_conn
- conn_type: MySQL
- host: localhost
- login: user
- password: password
- port: 3306