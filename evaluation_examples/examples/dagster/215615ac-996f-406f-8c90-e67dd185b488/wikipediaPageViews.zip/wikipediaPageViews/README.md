## Connection to MySQL database
conn_id: mysql_conn
conn_type: mysql
host: localhost
login: user
password: password
port: 3306