create user 'user'@'localhost' identified by 'password';
grant create, alter, drop, insert, update, index, delete, select, references, reload, file on *.* to 'user'@'localhost' with grant option;
flush privileges;

create database master;
use master;

create table pageview_counts (title varchar(255), views int, datetime varchar(255));
