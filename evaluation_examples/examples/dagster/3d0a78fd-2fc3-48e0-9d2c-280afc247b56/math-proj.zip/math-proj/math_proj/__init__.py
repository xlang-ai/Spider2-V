from dagster import Definitions, load_assets_from_modules

from . import assets
from .math_sensor import math_sensor

all_assets = load_assets_from_modules([assets])

defs = Definitions(
    assets=all_assets,
    sensors=[math_sensor]
)
