from dagster import sensor, RunRequest
from .math_job import math_job

@sensor(job=math_job, minimum_interval_seconds=31536000)
def math_sensor(context):
    value = int(context.cursor) if context.cursor else 0
    yield RunRequest(run_key=str(value), run_config={"ops": {"validate": {"config": {"value": value}}}})