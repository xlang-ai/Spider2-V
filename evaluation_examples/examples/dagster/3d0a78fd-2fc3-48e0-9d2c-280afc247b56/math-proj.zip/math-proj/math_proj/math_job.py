from dagster import op, job, get_dagster_logger, Config

class IntConfig(Config):
    value: int

@op
def validate(config: IntConfig):
    assert config.value == 123, "Wrong cursor value"
    get_dagster_logger().info("Validation passed")

@job
def math_job():
    validate()