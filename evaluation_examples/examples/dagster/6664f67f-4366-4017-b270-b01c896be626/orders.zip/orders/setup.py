from setuptools import find_packages, setup

setup(
    name="orders",
    packages=find_packages(exclude=["orders_tests"]),
    install_requires=[
        "dagster",
        "dagster-cloud"
    ],
    extras_require={"dev": ["dagster-webserver", "pytest"]},
)
