import pandas as pd


def main():
    orders_df = pd.read_csv("orders_data.csv")
    total_orders = len(orders_df)
    print(f"processing total {total_orders} orders")


if __name__ == "__main__":
    main()
