from dagster import op, asset, AssetIn, AssetOut
import pandas as pd

@op
def retrieve_csv(url):
    df = pd.read_csv(url)

    if "Title" in df.columns:
        title_col = "Title"
    else:
        title_col = "Movie"

    new_df = df[[title_col, "Year", "Genre"]]

    return new_df

@asset(
    io_manager_key="parquet"
)
def hollywood_movies():
    url = "https://raw.githubusercontent.com/reisanar/datasets/master/HollywoodMovies.csv"
    
    df = retrieve_csv(url)

    return df

@asset(
    io_manager_key="parquet"
)
def imdb_movies():
    url = "https://raw.githubusercontent.com/reisanar/datasets/master/IMDB_movies.csv"

    df = retrieve_csv(url)

    return df
