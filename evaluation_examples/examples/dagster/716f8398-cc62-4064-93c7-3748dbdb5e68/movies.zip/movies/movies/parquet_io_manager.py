import os
from typing import Union

import pandas as pd
from dagster import (
    ConfigurableIOManager,
    InputContext,
    OutputContext,
    _check as check,
)
from dagster._seven.temp_dir import get_system_temp_directory


class ParquetIOManager(ConfigurableIOManager):
    """This IOManager will take in a pandas dataframe and store it in parquet at the
    specified path.

    It stores outputs for different partitions in different filepaths.
    """

    base_path: str = get_system_temp_directory()

    @property
    def _base_path(self):
        return self.base_path

    def handle_output(self, context: OutputContext, obj: pd.DataFrame):
        pass

    def load_input(self, context):
        pass

    def _get_path(self, context: Union[InputContext, OutputContext]):
        key = context.asset_key.path[-1]

        return os.path.join(self._base_path, f"{key}.pq")
