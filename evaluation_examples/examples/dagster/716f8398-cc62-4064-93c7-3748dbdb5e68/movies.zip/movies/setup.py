from setuptools import find_packages, setup

setup(
    name="movies",
    packages=find_packages(exclude=["movies_tests"]),
    install_requires=[
        "dagster",
        "dagster-cloud"
    ],
    extras_require={"dev": ["dagster-webserver", "pytest"]},
)
