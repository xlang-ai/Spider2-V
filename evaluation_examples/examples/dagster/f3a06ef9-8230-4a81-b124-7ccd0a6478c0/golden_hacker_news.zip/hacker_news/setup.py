from setuptools import find_packages, setup

setup(
    name="hacker_news",
    packages=find_packages(exclude=["hacker_news_tests"]),
    install_requires=[
        "dagster",
        "dagster-cloud"
    ],
    extras_require={"dev": ["dagster-webserver", "pytest"]},
)
