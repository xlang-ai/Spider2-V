import json
import os

import requests
from dagster import asset # import the `dagster` library

@asset
def top10_story_ids() -> None:
    newstories_url = "https://hacker-news.firebaseio.com/v0/topstories.json"
    top_new_story_ids = requests.get(newstories_url).json()[:10]

    os.makedirs("data", exist_ok=True)
    with open("data/story_ids.json", "w") as f:
        json.dump(top_new_story_ids, f)
        
@asset
def top5_askstory_ids() -> None:
    newstories_url = "https://hacker-news.firebaseio.com/v0/askstories.json"
    top_new_story_ids = requests.get(newstories_url).json()[:5]

    os.makedirs("data", exist_ok=True)
    with open("data/askstory_ids.json", "w") as f:
        json.dump(top_new_story_ids, f)
        
@asset
def top5_showstory_ids() -> None:
    newstories_url = "https://hacker-news.firebaseio.com/v0/showstories.json"
    top_new_story_ids = requests.get(newstories_url).json()[:5]

    os.makedirs("data", exist_ok=True)
    with open("data/showstory_ids.json", "w") as f:
        json.dump(top_new_story_ids, f)
        
@asset
def top5_jobstory_ids() -> None:
    newstories_url = "https://hacker-news.firebaseio.com/v0/jobstories.json"
    top_new_story_ids = requests.get(newstories_url).json()[:5]

    os.makedirs("data", exist_ok=True)
    with open("data/jobstory_ids.json", "w") as f:
        json.dump(top_new_story_ids, f)
