from dagster import repository
from jobs.sklearn_job import sklearn_job


@repository
def sklearn_repo():
    return {
        "jobs": {
            "sklearn_job": lambda: sklearn_job 
        }
    }
