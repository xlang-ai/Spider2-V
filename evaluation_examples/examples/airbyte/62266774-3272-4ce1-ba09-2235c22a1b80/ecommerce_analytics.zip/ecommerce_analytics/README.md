# E-commerce Data Pipeline

## Goal

I want to build an e-commerce data pipeline using Airbyte, dbt and Snowflake. The main body of project codes has been finished. Please help me finish the remaining connection and debugging issues.

The complete task includes the following 2 stages:

1. Configure a connection in Airbyte to transfer data from Faker to Snowflake
    - Airbyte UI: localhost with port 8000
    - Database: raw_data
    - Warehouse: COMPUTE_WH
    - Role: ACCOUNTADMIN
    - Schema: PUBLIC
2. Use dbt to transform raw data into the target DB on Snowflake
    - Connector: Snowflake
    - Source Database: raw_data
    - Target Database: transformed_data
    - Schema: PUBLIC

## ENV Variables

The following variables have been set in their corresponding environment variables with the same names.

- SNOWFLAKE_HOST
- SNOWFLAKE_ACCOUNT
- SNOWFLAKE_USER
- SNOWFLAKE_PASSWORD

## Project Structure

Here is an overview of the project structure:

- dbt_project/: codes for dbt transformation
- setup.py: python library dependencies (already installed)
- README.md: this file
