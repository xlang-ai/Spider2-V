from setuptools import find_packages, setup

setup(
    name="airbyte-dbt",
    packages=find_packages(),
    install_requires=[
        "dbt-snowflake",
    ],
    extras_require={"dev": ["pytest"]},
)
