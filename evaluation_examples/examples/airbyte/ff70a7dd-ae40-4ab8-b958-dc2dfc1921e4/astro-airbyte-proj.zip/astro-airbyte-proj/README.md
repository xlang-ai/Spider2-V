# Overview
========

In this task, we are going to use Airflow to orchestrate the data synchronization of a built Airbyte connection from Faker source to local json files.

## Task Goal

- Instead of using Airbyte, construct a DAG called `faker_to_json_dag` to perform:
  1. trigger the connection defined in Airbyte
  2. wait for the completion of data synchronization
  2. among the received files, copy the file related to products from the original path into `./data/` folder in the current project and rename this file by removing the prefix `_airbyte_`


## Project Details

- Both the Airbyte and Airflow Web UI have been started in localhost with port 8000 and 8080 respectively
- Airbyte connection info:
  - launched via docker compose
  - basic auth: both are empty
    - user: ""
    - password: ""
  - source: Sample Data (Faker)
  - destination: Local JSON with path `/tmp/airbyte_local/json_data`
- Airflow Web UI:
  - launched with tool Astro-CLI
  - both the intermediate local path `/tmp/airbyte_local` and the final data path `./data/` have been mounted to the running container during initialization
  - apache-airflow-providers-airbyte has been installed before starting the Web UI (thus, no need to restart)