from airflow import DAG

import pendulum, os

with DAG(dag_id='faker_to_json_dag',
        start_date=pendulum.today('UTC').add(days=-1)
    ) as dag:

    pass
