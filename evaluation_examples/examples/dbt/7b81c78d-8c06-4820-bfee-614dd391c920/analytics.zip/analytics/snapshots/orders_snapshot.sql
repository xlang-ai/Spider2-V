{% snapshot orders_snapshot %}

{{
    config(

    )
}}

select * from {{ source('analytics', 'orders') }}

{% endsnapshot %}