## Detailed Testing Requirements

- columns ``customer_id`` and ``order_id`` in customers and stg_customers are unique and not empty
- column ``status`` must be value chosen from placed, shipped, completed, return_pending, returned
- ``customer_id`` in stg_orders is not null and is a foreign key in the referenced stg_customers
