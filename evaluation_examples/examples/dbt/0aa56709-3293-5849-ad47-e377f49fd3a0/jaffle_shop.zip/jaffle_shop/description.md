## Project Description Requirements

* ``customers`` model is described as "One record per customer".
* ``stg_customers`` model is described as "This model cleans up customer data".
* ``stg_orders`` model is described as "This model cleans up order data".
* add "Primary key" description to each table's primary key column.
* Add description for ``customers.first_order_date`` column: "NULL when a customer has not yet placed an order."