with source as (

    select * from {{ ref('logged_email_domains') }}

)


select * from source