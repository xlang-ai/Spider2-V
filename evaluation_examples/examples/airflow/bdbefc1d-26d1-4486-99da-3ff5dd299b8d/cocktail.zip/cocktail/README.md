## Task Overview
=======

## Fetching Data from TheCocktailDB

In this project, we define two DAGs `cocktail_producer_dag` and `cocktail_consumer_dag`:
- `cocktail_producer_dag`: each time this DAG will fetch information of one drink randomly from TheCocktailDB using its [free official API](https://www.thecocktaildb.com/api/json/v1/1/random.php"). The output result will be saved to the local folder `include`.
- `cocktail_producer_dag`: based on the produced outputs from `cocktail_producer_dag`, this DAG further processes the output results.

## Running Schedule

Currently, two DAGs are both configured to run regularly each day:
- `cocktail_producer_dag`: it is scheduled to run at 20:00 p.m. daily
- `cocktail_consumer_dag`: since this DAG is dependent on the fetched results of the producer, it is scheduled to run at 20:05 p.m. every day (a few minutes later than `cocktail_producer_dag`)