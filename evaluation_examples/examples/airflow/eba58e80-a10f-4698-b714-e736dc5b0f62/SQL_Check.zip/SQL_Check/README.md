Create connection: 

    Connection Id: sqlite_conn
    Connection Type: SQLite
    Host: /tmp/sqlite.db

The details of the check:

Create a custom check in file custom_check.sql

Check whether the happiness of bird after 2019(included) are lower than it before 2019.

Table name and connection id are defined in DAG.py

Then, set custom check task with name "custom_happiness_check" in DAG.
