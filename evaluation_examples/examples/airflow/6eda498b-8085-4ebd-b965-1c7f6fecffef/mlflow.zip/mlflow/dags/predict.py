"""
### Run predictions on a dataset using the MLFLow Provider and plot the results

This DAG utilizes the ModelLoadAndPredictOperator to run predictions on a dataset using a trained MLFlow model. The resulting
predictions are plotted against the true values.
"""

from airflow import Dataset
from airflow.decorators import dag, task
from pendulum import datetime
from astro import sql as aql
from astro.files import File
from airflow.operators.empty import EmptyOperator
import os
from mlflow_provider.operators.pyfunc import ModelLoadAndPredictOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
import pandas as pd


## AWS S3 parameters
AWS_CONN_ID = "aws_default"
BUCKET_NAME = "data"
MLFLOW_ARTIFACT_BUCKET = "mlflowdatapossums"

## Data parameters
TARGET_COLUMN = "taill"  # tail length in cm
FILE_TO_SAVE_PREDICTIONS = "possum_tail_length.csv"


@dag(
    schedule=[Dataset("model_trained")],
    start_date=datetime(2023, 1, 1),
    catchup=False,
    render_template_as_native_obj=True,
)
def predict():
    start = EmptyOperator(task_id="start")
    end = EmptyOperator(task_id="end")

    # Define an Airflow task fetch_feature_df_no_target that fetches feature data from a previous feature_eng DAG, drops any missing values, and drops the target column. It returns a NumPy array. The name of the target column is TARGET_COLUMN.
    @task
    def fetch_feature_df_no_target(target_column, **context):
        
        # Code Here

        return feature_df.to_numpy()

    # Define an Airflow task fetch_model_run_id that fetches the model run ID from a previous train DAG with dag_id="train", task_ids="train_model", include_prior_dates=True.
    @task
    def fetch_model_run_id(**context):
        
        # Code Here

        return model_run_id

    fetched_feature_df = fetch_feature_df_no_target(target_column=TARGET_COLUMN)
    fetched_model_run_id = fetch_model_run_id()

    # Define an Airflow task add_line_to_file that uses S3Hook to read the requirements.txt file of the model from S3, adds two lines for boto3 and pandas, and then uploads the updated contents back to S3. The AWS connection ID is AWS_CONN_ID and the name of the S3 bucket is MLFLOW_ARTIFACT_BUCKET.
    @task
    def add_line_to_file(**context):
        # Code Here

    # Create an instance of ModelLoadAndPredictOperator named run_prediction that loads the model and runs the prediction. The URI of the model is s3://{MLFLOW_ARTIFACT_BUCKET}/{{ ti.xcom_pull(task_ids='fetch_model_run_id')}}/artifacts/model and the data is fetched_feature_df.
    
    # Code Here

    # Define an Airflow task list_to_dataframe that converts the prediction results into a DataFrame.
    @task
    def list_to_dataframe(column_data):
        # Code Here
        return df

    prediction_data = list_to_dataframe(run_prediction.output)

    # Use the aql.export_file function to save the prediction results to S3. The path of the output file is os.path.join("s3://", BUCKET_NAME, FILE_TO_SAVE_PREDICTIONS).
    
    # Code Here

    (
        start
        >> [fetched_feature_df, fetched_model_run_id]
        >> add_line_to_file()
        >> run_prediction
        >> pred_file
        >> end
    )


predict()
