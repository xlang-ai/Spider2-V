The details of test functions:

test_dag_schedule_interval():
    
Purpose: Verify that the DAG's schedule interval is set to daily.
If wrong, return: DAG schedule interval is not set to daily.

test_task_workflow_order():

Prupose: Ensure that tasks in the DAG follow the correct execution order.
Expected order: ['fetch_activity', 'log_activity', 'analyze_activity']
If wrong, return: Tasks are not in the expected order: {expected_order}