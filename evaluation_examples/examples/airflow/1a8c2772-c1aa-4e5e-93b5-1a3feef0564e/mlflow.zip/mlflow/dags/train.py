"""
### Train a RidgeCV model using sklearn and track model versions with the MLFlow provider

This DAG utilizes the Astro Python SDK, MLFlow and Sklearn to train a machine learning model on a provided dataset.
"""

from airflow import Dataset
from airflow.decorators import dag, task_group, task
from pendulum import datetime
from astro import sql as aql
from astro.dataframes.pandas import DataFrame
from mlflow_provider.hooks.client import MLflowClientHook
from airflow.operators.empty import EmptyOperator
from sklearn.linear_model import RidgeCV
from mlflow_provider.operators.registry import (
    CreateRegisteredModelOperator,
    CreateModelVersionOperator,
    TransitionModelVersionStageOperator,
)
import numpy as np

FILE_PATH = "possum.csv"

## AWS S3 parameters
AWS_CONN_ID = "aws_default"
DATA_BUCKET_NAME = "data"
MLFLOW_ARTIFACT_BUCKET = "mlflowdatapossums"

## MLFlow parameters
MLFLOW_CONN_ID = "mlflow_default"
EXPERIMENT_NAME = "Possum_tails"
REGISTERED_MODEL_NAME = "Reg_RidgeCV_possums"
MAX_RESULTS_MLFLOW_LIST_EXPERIMENTS = 1000

## Data parameters
TARGET_COLUMN = "taill"  # tail length in cm


@dag(
    schedule=[Dataset("s3://" + DATA_BUCKET_NAME + "_" + FILE_PATH)],
    start_date=datetime(2023, 1, 1),
    catchup=False,
)
def train():
    start = EmptyOperator(task_id="start")
    end = EmptyOperator(task_id="end", outlets=[Dataset("model_trained")])

    # The fetch_feature_df task pulls the feature dataframe that was pushed to XCom in the previous DAG. It retrieves the ID of the MLFlow experiment that will be used to log the model by xcom_pull with following parameters: dag_id="feature_eng", task_ids="build_features", include_prior_dates=True.
    @task
    def fetch_feature_df(**context):
        "Fetch the feature dataframe from the feature engineering DAG."

        feature_df = context["ti"].xcom_pull(
            dag_id="feature_eng", task_ids="build_features", include_prior_dates=True
        )
        return feature_df

    @task
    def fetch_experiment_id(experiment_name, max_results=1000):
        "Get the ID of the specified MLFlow experiment."

        mlflow_hook = MLflowClientHook(mlflow_conn_id=MLFLOW_CONN_ID)
        experiments_information = mlflow_hook.run(
            endpoint="api/2.0/mlflow/experiments/search",
            request_params={"max_results": max_results},
        ).json()

        for experiment in experiments_information["experiments"]:
            if experiment["name"] == experiment_name:
                return experiment["experiment_id"]

        raise ValueError(f"{experiment_name} not found in MLFlow experiments.")

    # Train a model
    @aql.dataframe()
    def train_model(
        feature_df: DataFrame,
        experiment_id: str,
        target_column: str,
        model_class: callable,
        hyper_parameters: dict,
        run_name: str,
    ) -> str:
        "Train a model and log it to MLFlow."

        import mlflow

        # Call mlflow.sklearn.autolog() to enable automatic logging
        
        # Code Here

        # Drop rows with missing values
        
        # Code Here

        # Define the target column and the model
        
        # Code Here

        # Start an MLFlow run with mlflow.start_run(), setting the experiment_id and run_name. Use a with statement so the run is automatically closed when done.
        
        # Code Here
        return run_id

    fetched_feature_df = fetch_feature_df()
    fetched_experiment_id = fetch_experiment_id(experiment_name=EXPERIMENT_NAME)

    # Train model"model_trained" with following parameters: feature_df=fetched_feature_df, experiment_id=fetched_experiment_id, target_column=TARGET_COLUMN, model_class=RidgeCV, hyper_parameters={"alphas": np.logspace(-3, 1, num=30)}, run_name="RidgeCV"
    # Code Here

    @task_group
    def register_model():
        @task.branch
        def check_if_model_already_registered(reg_model_name):
            "Get information about existing registered MLFlow models."

            # Create an instance of MLflowClientHook named mlflow_hook, setting mlflow_conn_id and method. Then, use the mlflow_hook.run() method to send a GET request to api/2.0/mlflow/registered-models/get, passing reg_model_name as a request parameter. Convert the response to JSON format and assign it to get_reg_model_response.
            

            # Check if get_reg_model_response contains error_code. If it does, and if error_code is RESOURCE_DOES_NOT_EXIST, set reg_model_exists to False. Otherwise, if error_code is not RESOURCE_DOES_NOT_EXIST, raise a ValueError. If get_reg_model_response does not contain error_code, set reg_model_exists to True.
            

            # If reg_model_exists is True, return "register_model.model_already_registered". Otherwise, return "register_model.create_registered_model".


        # Create an instance of EmptyOperator named model_already_registered, setting task_id.
        

        # Create an instance of CreateRegisteredModelOperator named create_registered_model, setting task_id, name, and dictionary tags: {"key": "model_type", "value": "regression"},{"key": "data", "value": "possum"} .
        

        # Create an instance of CreateModelVersionOperator named create_model_version, setting task_id = "create_model_version", name = REGISTERED_MODEL_NAME, source = "s3://" + MLFLOW_ARTIFACT_BUCKET + "/" + "{{ ti.xcom_pull(task_ids='train_model') }}", run_id = "{{ ti.xcom_pull(task_ids='train_model') }}", trigger_rule = "none_failed".
        

        # Create an instance of TransitionModelVersionStageOperator named transition_model, setting task_id = "transition_model", name = REGISTERED_MODEL_NAME, version = "{{ ti.xcom_pull(task_ids='register_model.create_model_version')['model_version']['version'] }}", stage = "Staging", archive_existing_versions = True.


        (
            check_if_model_already_registered(reg_model_name=REGISTERED_MODEL_NAME)
            >> [model_already_registered, create_registered_model]
            >> create_model_version
            >> transition_model
        )

    (
        start
        >> [fetched_feature_df, fetched_experiment_id]
        >> model_trained
        >> register_model()
        >> end
    )


train()
