from mlflow.tracking import MlflowClient

client = MlflowClient(tracking_uri="http://127.0.0.1:5100")

experiment = client.get_experiment_by_name("Possum_tails")
if experiment:
    experiment_id = experiment.experiment_id

    run_names = ["Scaler"]
    latest_runs = []
    
    for name in run_names:
        runs = client.search_runs([experiment_id], filter_string=f"tags.mlflow.runName = '{name}'", order_by=["start_time desc"], max_results=1)
        if runs:
            latest_runs.extend(runs)
        else:
            print(f"No runs found for {name}, task failed")

    if latest_runs:
        for run in latest_runs:
            run_name = run.data.tags.get('mlflow.runName')
            status = run.info.status
            if status == 'FINISHED':
            	print(f"Run Name: {run_name}, Status: success")
            else:
            	print(f"Run Name: {run_name}, Status: failed")
            	break

    else:
        print("Runs status: failed.")
else:
    print("Experiment 'Possum_tails' activation status: failed.")