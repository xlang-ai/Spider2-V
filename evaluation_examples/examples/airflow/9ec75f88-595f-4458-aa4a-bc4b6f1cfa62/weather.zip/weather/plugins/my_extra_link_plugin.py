from airflow.plugins_manager import AirflowPlugin
from airflow.models.baseoperator import BaseOperatorLink
from airflow.providers.http.operators.http import SimpleHttpOperator

class WTTRWeatherLink(BaseOperatorLink):


class HTTPDocsLink(BaseOperatorLink):


class AirflowExtraLinkPlugin(AirflowPlugin):
    name = "extra_link_plugin"
    operator_extra_links = [
        WTTRWeatherLink(),
        HTTPDocsLink(),
    ]