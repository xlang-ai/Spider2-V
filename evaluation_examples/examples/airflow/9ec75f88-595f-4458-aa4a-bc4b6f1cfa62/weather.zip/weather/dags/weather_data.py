from airflow.models.dag import DAG
from airflow.providers.http.operators.http import SimpleHttpOperator
from pendulum import datetime

with DAG(
    dag_id="weather_data_dag",
    start_date=datetime(2024,4,1),
    schedule_interval="@daily",
    catchup=False
):

    get_hong_kong_weather = SimpleHttpOperator(
        task_id="get_hong_kong_weather",
        http_conn_id="http_weather_service",
        endpoint="HongKong?format=%l:+%c+%t+%h+%w+%m",
        method="GET",
        response_filter=lambda response: response.text,
        log_response=True
    )

