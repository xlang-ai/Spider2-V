from airflow.decorators import task, dag
from pendulum import datetime
import requests

@dag(
    start_date=datetime(2024,4,1),
    schedule="@daily",
    catchup=False,
)
def task_today():

    @task
    def tell_me_what_to_do():
        response = requests.get("https://www.boredapi.com/api/activity")
        return response.json()["activity"]

    tell_me_what_to_do()

task_today()

