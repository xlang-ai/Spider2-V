Here are details of document I would like to add:

Markdown content with name: "doc_md_doc" : 

"""

### Purpose of this task

This task **boldly** suggests a daily activity to occupy my time.

Weather today: https://wttr.in/HongKong

If I don't like the suggested activity I can always play some games instead.

Check steam for my game: https://store.steampowered.com/

Sports today: running
gear: |
    - running shoes
    - sports clothes
    - a healthy lung
I hate running

But I can watch some anime when running: https://www.bilibili.com/

"""

Please create documents according to the instruction with content and correct format as instructed above.