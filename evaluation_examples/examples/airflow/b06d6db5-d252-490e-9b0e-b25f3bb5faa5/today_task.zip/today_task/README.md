============================= test session starts ==============================
platform linux -- Python 3.11.7, pytest-7.4.0, pluggy-1.0.0
rootdir: /home/user/Desktop/task_today/tests/dags
plugins: anyio-4.2.0, time-machine-2.14.1
collected 3 items

test_dag_example.py .FF                                                  [100%]

=================================== FAILURES ===================================
__________________________ test_dag_schedule_interval __________________________

    def test_dag_schedule_interval():
        """Verify that the DAG's schedule interval is set to daily."""
        dag = dag_bag.get_dag('activity_suggestion_dag')
>       assert dag.schedule_interval == '@daily', "DAG schedule interval is not set to daily."
E       AssertionError: DAG schedule interval is not set to daily.
E       assert '@hourly' == '@daily'
E         - @daily
E         + @hourly

test_dag_example.py:62: AssertionError
___________________________ test_task_workflow_order ___________________________

    def test_task_workflow_order():
        """Ensure that tasks in the DAG follow the correct execution order."""
        dag = dag_bag.get_dag('activity_suggestion_dag')
        task_ids = [task.task_id for task in dag.tasks]
    
        expected_order = ['fetch_activity', 'log_activity', 'analyze_activity']
>       assert task_ids == expected_order, f"Tasks are not in the expected order: {expected_order}"
E       AssertionError: Tasks are not in the expected order: ['fetch_activity', 'log_activity', 'analyze_activity']
E       assert ['fetch_activ...log_activity'] == ['fetch_activ...yze_activity']
E         At index 1 diff: 'analyze_activity' != 'log_activity'
E         Use -v to get more diff

test_dag_example.py:71: AssertionError
=========================== short test summary info ============================
FAILED test_dag_example.py::test_dag_schedule_interval - AssertionError: DAG schedule interval is not set to daily.
FAILED test_dag_example.py::test_task_workflow_order - AssertionError: Tasks are not in the expected order: ['fetch_activity', 'lo...
========================= 2 failed, 1 passed in 2.15s ==========================
