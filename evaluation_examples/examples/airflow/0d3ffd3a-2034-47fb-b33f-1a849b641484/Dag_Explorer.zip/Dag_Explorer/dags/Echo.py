from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime

default_args = {
    'owner': 'computer_science',
    'start_date': datetime(2023, 1, 1),
    'retries': 1,
}

with DAG('echo_hello', default_args=default_args, schedule_interval='@daily', tags=['Example']) as dag:
    echo_hello = BashOperator(
        task_id='echo_hello',
        bash_command='echo "Hello, World!"'
    )

    echo_hello
