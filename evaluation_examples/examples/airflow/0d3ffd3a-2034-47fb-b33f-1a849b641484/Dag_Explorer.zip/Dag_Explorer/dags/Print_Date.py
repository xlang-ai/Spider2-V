from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime

default_args = {
    'owner': 'Astro',
    'start_date': datetime(2023, 1, 1),
    'retries': 1,
}

with DAG('print_date', default_args=default_args, schedule_interval='@hourly', tags=['Astro']) as dag:
    print_date = BashOperator(
        task_id='print_date',
        bash_command='date'
    )

    print_date
