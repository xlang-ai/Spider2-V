from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'airflow',
    'start_date': datetime(2023, 1, 1),
    'retries': 1,
}

with DAG('sleep_task', default_args=default_args, schedule_interval='@daily', tags=['Random']) as dag:
    sleep = BashOperator(
        task_id='sleep',
        bash_command='sleep 5'
    )

    sleep
