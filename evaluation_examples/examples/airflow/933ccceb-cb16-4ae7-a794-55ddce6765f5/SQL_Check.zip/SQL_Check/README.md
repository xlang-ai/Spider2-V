Create conection: 

    Connection Id: sqlite_conn
    Connection Type: SQLite
    Host: /tmp/sqlite.db


The details of the check:

Create a column check with name "check_column"
Select data with bird_name not equal to Null

Check whether bird name has no "Null", and the these datas have distinct names.
Check whether year of observation is from year 2018 to 2023.
Check whether bird happiness numbers are valid (min 1 and max 10).

Create a table check with name "check_table"

Check whether the average bird happiness after 2018(excluded) are greater or equal to 8.
